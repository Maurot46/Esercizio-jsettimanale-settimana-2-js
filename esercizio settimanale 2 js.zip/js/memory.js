let arrayAnimali = ['🐱', '🦉', '🐾', '🦁', '🦋', '🐛', '🐝', '🐬', '🦊', '🐨', '🐰', '🐯', '🐱', '🦉', '🐾', '🦁', '🦋', '🐛', '🐝', '🐬', '🦊', '🐨', '🐯', '🐰'];


  var arrayComparison = [];
  
  document.body.onload = startGame();
  
  var interval;//intervallo timer variabile globale
  var iconsFind = document.getElementsByClassName("find");
  var modal = document.getElementById('modal');//finestra modale fine gioco
  var timer = document.querySelector(".timer");//timer avanzamento
 
  
  function shuffle(a) {//funzione shuffle mischia le carte in modo casuale
    var currentIndex = a.length;//definisco un indice corrente
    var temporaryValue, randomIndex;
  
    while (currentIndex !== 0) {
      randomIndex = Math.floor(Math.random() * currentIndex);//mischio le carte in maniera casuale
      currentIndex -= 1;
      temporaryValue = a[currentIndex];
      a[currentIndex] = a[randomIndex];
      a[randomIndex] = temporaryValue;
    }
    return a;
  }
  
  function playAgain(){
    modal.classList.remove("active");
    startGame();//chiamo la funzione startGame che avvia il gioco
  }
  
  function startGame(){
    clearInterval(interval);//pulisce il timer
    arrayConfronto = [];//crea array dove passare tutte le icone
  
    var arrayShuffle = shuffle(arrayAnimali);//Msichio le icone
  
    var lista = document.getElementById('griglia');
    while (lista.hasChildNodes()) {  
      lista.removeChild(lista.firstChild);
    }
  
    for(var i = 0; i < 24; i++){    
      var box = document.createElement('div');//creo il box che contiene le carte
      var element = document.createElement('div');//creo i div che contengono i valori dell'array animali
      element.className = 'icon';
      document.getElementById('griglia').appendChild(box).appendChild(element);
      element.innerHTML = arrayShuffle[i];
    }
  
  
    startTimer();//chiamo la funzione timer
  
    var icon = document.getElementsByClassName("icon");
    var icons = [...icon];//ricevo tutti i valori
  
    for (var i = 0; i < icons.length; i++){
      icons[i].addEventListener("click", displayIcon);
      icons[i].addEventListener("click", openModal);
    }
  }
  
  
  function displayIcon(){//mostra le carte
  
    var icon = document.getElementsByClassName("icon"); //definisco una varibile per le icone
    var icons = [...icon];//ricevo i valori dell'array animali
  
    this.classList.toggle("show");
    arrayComparison.push(this);
  
    var len = arrayComparison.length;
    if(len === 2){
      if(arrayComparison[0].innerHTML === arrayComparison[1].innerHTML){
        arrayComparison[0].classList.add("find","disabled");
        arrayComparison[1].classList.add("find","disabled");
        arrayComparison = [];               
      } else {
        icons.forEach(function(item){
          item.classList.add('disabled');
        });
        setTimeout(function(){//gestisco il timeout delle carte dopo 700ms le carte si rigirano automaticamente
          arrayComparison[0].classList.remove("show");//gestisco 1 delle due carte nascondendola
          arrayComparison[1].classList.remove("show");//gestisco la 2 delle due carte nascondendola
          icons.forEach(function(item){
            item.classList.remove('disabled');
            for(var i = 0; i < iconsFind.length; i++){
                iconsFind[i].classList.add("disabled");
              }
          });
          arrayComparison = [];
        },700); 
       }
    }
  }
  
  
  function openModal(){  //gestisco apertura finistra modale alla vincita del gioco
    if (iconsFind.length == 24){//se il numero di icone girate è uguale a 24
      clearInterval(interval);//pulisco il timer
      modal.classList.add("active");//attivo la finestra modale
      document.getElementById("tempoTrascorso").innerHTML = timer.innerHTML;//stampo a schermo il tempo trascorso
      closeModal();//chiamo il pulsante per chiudere la finestra modale
    }
  }
  
  function closeModal(){  //pulsante per chiudere la finestra modale
    closeicon.addEventListener("click", function(){//gestisco il click
      modal.classList.remove("active");// rimuovo la finestra modale
      startGame();//faccio rimpartire il gioco
    });
  }
  
  
  function startTimer(){//funzione timer

    var s = 0; var  m = 0; var h = 0;//definisco i 3 valori in questo caso secondi, minuti e ore, eventualmente ne posso definire anche di più
  
    interval = setInterval(function(){
    timer.innerHTML = 'Tempo: ' + m + " min " + s + " sec";//stampo il risultato del loop nell'HTML
      s++;//gestice l'incremento dei secondi
      if(s == 60){//quando i secondi diventeranno di valore e tipo = a 60 incrementa di 1 i minuto
        m++;
        s = 0;
      }
      if(m == 60){//incremento di 1 ora quando minuti raggiunge 60
        h++;
        m = 0;
      }
    },1000);//regolo l'intervallo per creare l'animazione di scorrimento
  }